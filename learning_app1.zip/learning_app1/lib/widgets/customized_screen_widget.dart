import 'package:flutter/material.dart';

class CustomBackground extends StatelessWidget {
  //final Widget child; // The widget to display on top of the background
  final String imagePath; // Path to the background image
  final String child;

  const CustomBackground({
    super.key,
    //required this.child,
    required this.imagePath, required this.child
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: AssetImage('assets/images/1beb34e29964e698b7f79b49fe3b1b21.jpg'), // Background image
          fit: BoxFit.cover, // Cover the entire screen
        ),
      ),
      //child: child, // Display the child widget on top of the background
    );
  }
}

// import 'package:flutter/material.dart';
//
// class CustomBackground extends StatelessWidget {
//   final Widget child;
//
//   const CustomBackground({super.key, required this.child});
//
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       decoration: const BoxDecoration(
//         image: DecorationImage(
//           image: AssetImage('assets/images/1beb34e29964e698b7f79b49fe3b1b21.jpg'), // Background image
//           fit: BoxFit.cover, // Cover the entire screen
//       ),
//       //child: child, // Include the child widget here
//     ));
//   }
// }





