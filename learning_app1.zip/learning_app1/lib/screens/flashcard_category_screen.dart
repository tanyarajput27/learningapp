import 'package:flutter/material.dart';
import 'dbms_flashcard_screen.dart';
import 'os_flashcard_screen.dart';
import 'cn_flashcard_screen.dart';
import '../widgets/customized_screen_widget.dart';

class FlashcardCategoryScreen extends StatelessWidget {
  const FlashcardCategoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Topics'),
        centerTitle: false,
        backgroundColor: Colors.pinkAccent[100],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const FlashcardScreen()),
                );
                // Action for OS flashcards
                print('Operating Systems Flashcards');
              },
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 60, horizontal: 50),
                backgroundColor: Colors.yellow, // Button color
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero, // No rounded corners
                ),
                textStyle: const TextStyle(fontSize: 27, height: 2,
                    fontWeight: FontWeight.bold, decorationColor: Colors.red),
              ),
              child: const Text('Operating Systems (OS)'),
            ),
            ElevatedButton(
              onPressed: () {
                // Action for CN flashcards
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const FlashcardScreen1()),
                );
                print('Computer Networks Flashcards');
              },
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 60, horizontal: 50),
                backgroundColor: Colors.yellow, // Button color
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero, // No rounded corners
                ),
                textStyle: const TextStyle(fontSize: 27, height: 2,
                fontWeight: FontWeight.bold, decorationColor: Colors.red),
              ),
              child: const Text('Computer Networks (CN)'),
            ),
            ElevatedButton(
              onPressed: () {
                // Action for DBMS flashcards
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const FlashcardScreen2()),
                );
                print('Database Management Systems Flashcards');
              },
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 60, horizontal: 50),
                backgroundColor: Colors.yellow, // Button color
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero, // No rounded corners
                ),
                textStyle: const TextStyle(fontSize: 27, height: 2,
                    fontWeight: FontWeight.bold, decorationColor: Colors.red),
              ),
              child: const Text('Database Management Systems (DBMS)'),
            ),
            // ElevatedButton(
            //   onPressed: () {
            //     // Action for OOPS flashcards
            //     print('Object-Oriented Programming Systems Flashcards');
            //   },
            //   style: ElevatedButton.styleFrom(
            //     padding: const EdgeInsets.symmetric(vertical: 30, horizontal: 50),
            //     backgroundColor: Colors.yellow, // Button color
            //     shape: const RoundedRectangleBorder(
            //       borderRadius: BorderRadius.zero, // No rounded corners
            //     ),
            //     textStyle: const TextStyle(fontSize: 27, height: 2,
            //         fontWeight: FontWeight.bold, decorationColor: Colors.red),
            //   ),
            //   child: const Text('Object-Oriented Programming Systems (OOPS)'),

            //),
          ],
        ),
      ),
    );
  }
}
