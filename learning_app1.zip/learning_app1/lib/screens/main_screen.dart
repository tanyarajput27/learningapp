import 'package:flutter/material.dart';
import 'package:learning_app1/screens/flashcard_category_screen.dart';
import 'package:learning_app1/screens/quiz_screen.dart';
import 'os_flashcard_screen.dart';
import 'package:google_fonts/google_fonts.dart';
import '../widgets/customized_screen_widget.dart';


class MainScreen extends StatelessWidget {
  const MainScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("LearnOn",
          style:GoogleFonts.ptSerif(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),

      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  //MaterialPageRoute(builder: (context) =>  const CustomBackground(imagePath:'- images/1beb34e29964e698b7f79b49fe3b1b21.jpg')),
                  MaterialPageRoute(builder: (context) =>  const FlashcardCategoryScreen()),
                );
              },
              style: ElevatedButton.styleFrom(
                foregroundColor: Colors.black,  // Text color
                padding: const EdgeInsets.symmetric(horizontal: 70, vertical: 20),
                backgroundColor: Colors.pinkAccent,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                    side: const BorderSide(
                      color:Colors.purple,
                      width:7,
                      style: BorderStyle.solid,
                    )
                ),
                elevation: 4,
              ),
              child:  Text("Flashcards",
              style:GoogleFonts.ptSerif(
                fontSize: 40,
                fontWeight: FontWeight.bold,
              ),
              )
            ),


            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => QuizScreen()),
                );
              },

              style: ElevatedButton.styleFrom(
                foregroundColor: Colors.black,  // Text color
                padding: const EdgeInsets.symmetric(horizontal: 70, vertical: 20),
                backgroundColor: Colors.pinkAccent[100],

                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                  side: const BorderSide(
                    color:Colors.purple,
                    width: 7,
                    style: BorderStyle.solid,
                  )
                ),
                elevation: 4,
              ),
              child: Text("Quiz",
                style:GoogleFonts.ptSerif(
                  fontSize: 40,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}