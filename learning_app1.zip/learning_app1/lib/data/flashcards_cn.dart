import '../../models/flashcard.dart';

final List<Flashcard> flashcards = [
  Flashcard(
    question: "A network",
    answer: "collection of computers, servers, mainframes, network devices, and other hardware and software components connected together to allow communication and resource sharing.",

  ),
  Flashcard(
    question: " Importance of computer networks",
    answer: "communication, resource sharing, information access, business operations, flexibility and scalability",

  ),
  Flashcard(
    question: "IP address",
    answer: "unique numeric identifier assigned to every device that connects to a network.",

  ),
  Flashcard(
    question: "IP address",
    answer: "unique numeric identifier assigned to every device that connects to a network.",

  ),
  Flashcard(
    question: "How do networking protocols use IP addresses?",
    answer: "to route data packets between devices.",

  ),
  Flashcard(
    question: "MAC address",
    answer: "A MAC (Media Access Control) address is a unique identifier assigned to a network interface controller (NIC) that is used as a network address in communications within a network segment.",

  ),
  Flashcard(
    question: "OSI model",
    answer: "Open Systems Interconnection model is a conceptual model that describes the communication functions of a network. ",

  ),

];
