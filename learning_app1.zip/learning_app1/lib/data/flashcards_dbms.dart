import '../models/flashcard.dart';

final List<Flashcard> flashcards = [
  Flashcard(
    question: "Database",
    answer: " collection of data related to a specific task, event or purpose that is organised and stored in a way that makes it easy to retrieve when required",

  ),
  Flashcard(
    question: "DBMS",
    answer: "store databases electronically using a database management system(DBMS) that makes it easy to query, control and update databases.",

  ),
  Flashcard(
    question: "advantages of using a DBMS",
    answer: "easy to organise, access and use the data; validate the data on the basis of predefined data types;  ensures data consistency; helps avoid data redundancy; provide restricted access to data based on the role and privileges of the user.",

  ),
  Flashcard(
    question: "DBMS",
    answer: "store databases electronically using a database management system(DBMS) that makes it easy to query, control and update databases.",

  ),Flashcard(
    question: " normalisation",
    answer: " process used to remove redundant data while keeping the data integrity intact.",

  ),Flashcard(
    question: "view",
    answer: "A view is a virtual table that displays a subset of data from different tables based on a query that we run on the database",
  ),
  Flashcard(
    question: "SQL",
    answer: "SQL is a standard programming language designed to handle and operate relational databases",
  ),
  Flashcard(
    question: "Main components of SQL",
    answer: " Data Definition Language (DDL), Data Manipulation Language (DML), Data Control Language (DCL) and Transaction Control Commands.",
  ),
];
