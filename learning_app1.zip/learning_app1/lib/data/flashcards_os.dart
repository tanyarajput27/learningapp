import '../models/flashcard.dart';

final List<Flashcard> flashcards = [
  Flashcard(
    question: "Operating System",
    answer: "an interface between computer hardware and computer users",

  ),
  Flashcard(
    question: " some of the standard services by OS",
    answer: "User interface, Program execution, I/O operations, File-system manipulation, Communications, Error detection, Resource allocation etc",

  ),
  Flashcard(
    question: "List some crucial functions of os",
    answer: "memory management, processor management, device management, file management, security, system performance control, job accounting etc",

  ),
  Flashcard(
    question: "Types of os",
    answer: "Batched, distributed, time sharing, multi programmed, real time",

  ),
  Flashcard(
    question: "kernel in an OS",
    answer: " core and most important part of a computer operating system that provides essential services for all parts of the OS.",

  ),
  Flashcard(
    question: "Process",
    answer: "An executing program in an OS",
  ),
  Flashcard(
    question: "Different states of a process in os",
    answer: "new state, running state, waiting state, ready state, terminated state",
  ),

];
