import 'package:flutter/material.dart';
import '../widgets/flashcard_widget.dart';
import '../widgets/flip_card_widget.dart';
import '../data/flashcards_os.dart';

class FlashcardScreen extends StatefulWidget {
  const FlashcardScreen({super.key});

  @override
  _FlashcardScreenState createState() => _FlashcardScreenState();
}

class _FlashcardScreenState extends State<FlashcardScreen> {
  int currentIndex = 0;

  void nextCard() {
    setState(() {
      currentIndex = (currentIndex + 1) % flashcards.length;
    });
  }

  void previousCard() {
    setState(() {
      currentIndex = (currentIndex - 1 + flashcards.length) % flashcards.length;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("OS Flashcards",
          style: TextStyle(fontSize: 25,
          fontWeight: FontWeight.bold,
          color: Colors.purple),
        ),
      ),
      body: Center(
    child: Card(
    color: Colors.green[300], // Change this to your desired color
    elevation: 5, // Adds shadow
    shape: RoundedRectangleBorder(
    borderRadius: BorderRadius.circular(15), // Rounded edges
    ),
    
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // FlashcardWidget(flashcard: flashcards[currentIndex]),
            FlipCardWidget(
              frontText: flashcards[currentIndex].question,
              backText: flashcards[currentIndex].answer,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                ElevatedButton(
                  onPressed: previousCard,
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 25),
                    backgroundColor: Colors.yellow[200], // Button color
                    shape:  RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                      // No rounded corners
                    ),
                    textStyle: const TextStyle(fontSize: 20, height: 1,
                        fontWeight: FontWeight.bold, decorationColor: Colors.black),
                  ),
                  child: const Text("Previous"),
                ),
                ElevatedButton(
                  onPressed: nextCard,
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 35),
                    backgroundColor: Colors.yellow[200], // Button color
                    shape:  RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20), // No rounded corners
                    ),
                    textStyle: const TextStyle(fontSize: 20, height: 1,
                        fontWeight: FontWeight.bold, decorationColor: Colors.black),
                  ),
                  child: const Text("Next"),
                ),
              ],
            ),
          ],
        ),
      ),
    ));
  }
}
