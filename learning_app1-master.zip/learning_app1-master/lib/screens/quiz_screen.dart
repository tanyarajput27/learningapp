import 'package:flutter/material.dart';

import '../data/flashcards_os.dart';


class QuizScreen extends StatefulWidget {
  const QuizScreen({super.key});

  @override
  _QuizScreenState createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  int currentQuestion = 0;
  int score = 0;

  void checkAnswer(String userAnswer) {
    String correctAnswer = flashcards[currentQuestion].answer;
    if (userAnswer == correctAnswer) {
      setState(() {
        score++;
      });
    }
    nextQuestion();
  }

  void nextQuestion() {
    setState(() {
      currentQuestion = (currentQuestion + 1) % flashcards.length;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Quiz"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              flashcards[currentQuestion].question,
              style: const TextStyle(fontSize: 20),
            ),
            ElevatedButton(
              onPressed: () => checkAnswer("Correct Answer"),
              child: const Text("Option 1"),
            ),
            ElevatedButton(
              onPressed: () => checkAnswer("Wrong Answer"),
              child: const Text("Option 2"),
            ),
            Text("Score: $score"),
          ],
        ),
      ),
    );
  }
}
