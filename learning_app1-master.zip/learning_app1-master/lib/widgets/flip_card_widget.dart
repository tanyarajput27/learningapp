import 'package:flutter/material.dart';

class FlipCardWidget extends StatefulWidget {
  final String frontText;
  final String backText;

  FlipCardWidget({required this.frontText, required this.backText});

  @override
  _FlipCardWidgetState createState() => _FlipCardWidgetState();
}

class _FlipCardWidgetState extends State<FlipCardWidget>
    with SingleTickerProviderStateMixin {
  bool isFlipped = false;
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _animation = Tween<double>(begin: 0, end: 1).animate(_controller);
  }

  void toggleCard() {
    setState(() {
      if (isFlipped) {
        _controller.reverse();
      } else {
        _controller.forward();
      }
      isFlipped = !isFlipped;
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: toggleCard,
      child: AnimatedBuilder(
        animation: _animation,
        builder: (context, child) {
          final isFront = _animation.value < 0.5;

          return Transform(
            alignment: Alignment.center,
            transform: Matrix4.rotationY(_animation.value * 3.14159265359),
            child: isFront
                ? _buildCard(widget.frontText)
                : Transform(
              alignment: Alignment.center,
              transform: Matrix4.rotationY(3.14159265359),
              child: _buildCard(widget.backText),
            ),
          );
        },
      ),
    );
  }

  Widget _buildCard(String text) {
    return Container(
      height: 300,
      width: 400,
      decoration: BoxDecoration(
        color: Colors.blue[200],
        borderRadius: BorderRadius.circular(20),
        boxShadow: const [
          BoxShadow(
            color: Colors.black26,
            blurRadius: 7,
            offset: Offset(20, 10),
          ),
        ],
      ),
      child: Center(
        child: Text(
          text,
          style: const TextStyle(
            color: Colors.deepPurple,
            fontSize: 27,
            fontWeight: FontWeight.bold,
          ),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
// TODO Implement this library.